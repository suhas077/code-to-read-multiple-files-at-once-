#include<stdio.h>
#include<stdlib.h>
#include "server.h"
void comp(int num,int n)
{
    int pos,count;
    int i;
    char ignore[1024];
    int filenumber;
    char filename[1024];

    FILE *fp;
for(filenumber=1;filenumber<n;filenumber++)
{
    sprintf(filename,"file%d.txt",filenumber);
    fp=fopen(filename,"r");
    char (*array)[4096];
    if(num<0){
        printf("Invalid number\n");

    }
    array=malloc(4096 * (num+1));
    fgets(ignore,sizeof(ignore),fp);
    for(count=pos=0;fgets(array[pos],4096,fp) !=NULL;count++){
        if(count<num)
            fputs(array[pos],stdout);
        if(++pos >= num+1)
            pos=0;

    }
    if(count>num)
    {
        pos=count-num;
        if(pos>num){
            printf("the last line or last %d lines are..\n",num);
        }else{
            pos=num;
        }
        for(;pos <count;pos++){
            fputs(array[pos % (num+1)],stdout);
        }
        }
    }
 fclose(fp);   
}

