#include <stdio.h>
#include "server.h"
#include<stdlib.h>

int main(int argc, char *argv[])
{
 int num;
int i;
int a;
printf("enter the number of lines u want to print from the top and the bottom\n");
 scanf("%d",&num);

    FILE *fp;
    if (argc < 2) {
        printf("please enter filename to invoke\n");
    }
for(i=1;i<argc;i++)
{
    fp = fopen(argv[i], "r");
    if (fp == NULL) {
        printf("Cannot open file or file does not exist\n");
	exit(0);
    }}
a=argc;
comp(num,a);

}
